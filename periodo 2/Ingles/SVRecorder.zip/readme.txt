=====================================================================
StepVoice Recorder 1.0b
Copyright (c) 2003 StepVoice Software
All rights reserved
=====================================================================

Table of Contents:
  Introduction
  System requirements
  Contact us
  
---------------------------------------------------------------------
Introduction

  StepVoice Recorder is a simple sound recording program for
Windows 9x/ME/2000/XP with direct MP3 encoding. It can be used for
recording from: microphone, internet streaming audio, or music played
by Winamp, Windows Media Player, Real Player, games, etc.
To select recording stream use standart Windows mixer.

---------------------------------------------------------------------
System requirements

  * Pentium 200MHZ CPU or higher
  * 32Mb RAM or more
  *  1Mb free hard disk for program
    (XXX Mb for sound recording)
  * Sound Card
  * Microphone

---------------------------------------------------------------------
Contact us

  If you have any comments or concerns about StepVoice Recorder,
feel free to email us: support@stepvoice.com

You can download latest version of StepVoice Recorder through our
site: http://www.stepvoice.com
                     

Thank you for using StepVoice Recorder
=====================================================================
